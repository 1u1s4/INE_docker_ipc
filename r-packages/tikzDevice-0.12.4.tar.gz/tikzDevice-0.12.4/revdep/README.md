# Platform

|field    |value                         |
|:--------|:-----------------------------|
|version  |R version 3.5.2 (2018-12-20)  |
|os       |Debian GNU/Linux bullseye/sid |
|system   |x86_64, linux-gnu             |
|ui       |RStudio                       |
|language |en_US:en                      |
|collate  |en_US.UTF-8                   |
|ctype    |en_US.UTF-8                   |
|tz       |Europe/Berlin                 |
|date     |2019-08-07                    |

# Dependencies

|package    |  old|new    |Δ  |
|:----------|----:|:------|:--|
|tikzDevice | 0.12|0.12.3 |*  |
|filehash   |   NA|2.4-2  |*  |

# Revdeps

