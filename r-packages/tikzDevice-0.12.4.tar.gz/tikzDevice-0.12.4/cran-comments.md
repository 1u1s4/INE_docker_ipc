This upload primarily removes usage of "sprintf".

## Test environments

* local:  Linux with R 4.2.1
* GitHub:
    * Ubuntu, R release, R-devel
* winbuilder: Windows, R-devel

## R CMD check results

0 errors | 0 warnings | 0 notes

