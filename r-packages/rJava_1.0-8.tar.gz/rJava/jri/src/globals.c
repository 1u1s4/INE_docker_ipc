#include <jni.h>

jobject engineObj;
jclass engineClass;
JNIEnv *eenv;
