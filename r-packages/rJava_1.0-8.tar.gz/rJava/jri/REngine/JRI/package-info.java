/**
 * REngine-based interface to JRI
 *
 * <p>
 * Currently it uses low-level calls from org.rosuda.JRI.Rengine, but
 * all REXP representations are created based on the org.rosuda.REngine API
 */
package org.rosuda.REngine.JRI ;

